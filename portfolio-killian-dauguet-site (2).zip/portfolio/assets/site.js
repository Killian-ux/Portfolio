(() => {
  const d = document, root = d.documentElement;
  const $ = (s, r = d) => r.querySelector(s), $$ = (s, r = d) => [...r.querySelectorAll(s)];
  const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const FINE = matchMedia('(hover:hover) and (pointer:fine)').matches;
  const EASE = 'transform .65s cubic-bezier(.76,0,.24,1)';
  const curtain = $('#curtain');

  /* ---------- Lettres élastiques (le texte reste lisible par Google et les lecteurs d'écran) ---------- */
  const BASE = 100, MAX = 125, letters = [];
  $$('[data-elastic]').forEach(el => {
    const t = el.dataset.elastic;
    el.textContent = '';
    const sr = d.createElement('span'); sr.className = 'sr'; sr.textContent = t;
    const wrap = d.createElement('span'); wrap.setAttribute('aria-hidden', 'true'); wrap.style.whiteSpace = 'nowrap';
    [...t].forEach((c, i) => {
      const s = d.createElement('span'); s.className = 'ch'; s.style.setProperty('--i', i);
      s.textContent = c === ' ' ? '\u00a0' : c;
      const w = FINE && !RM ? BASE : 112; s.style.fontStretch = w + '%';
      wrap.appendChild(s); letters.push({ el: s, w });
    });
    el.append(sr, wrap);
  });

  /* ---------- Texte qui se remplit au scroll ---------- */
  const fill = $('[data-fill]');
  let fw = [];
  if (fill) {
    fill.innerHTML = fill.textContent.trim().split(/\s+/).map(w => `<span class="w${RM ? ' on' : ''}">${w}</span>`).join(' ');
    fw = $$('.w', fill);
  }
  const nav = $('#nav'), rp = $('.read-progress');
  let lastY = 0;
  function onScroll() {
    const y = scrollY;
    if (fill && !RM) {
      const r = fill.getBoundingClientRect(), vh = innerHeight;
      const p = Math.min(1, Math.max(0, (vh * .88 - r.top) / (r.height + vh * .4)));
      fw.forEach((w, i) => w.classList.toggle('on', i / fw.length < p));
    }
    if (nav) nav.classList.toggle('hide', y > lastY && y > 240 && !d.body.classList.contains('menu-open'));
    if (rp) rp.style.transform = `scaleX(${Math.min(1, y / Math.max(1, d.body.scrollHeight - innerHeight))})`;
    lastY = y;
  }
  addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- Apparition au scroll ---------- */
  const rv = $$('.rv');
  if (!RM && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
    rv.forEach(el => io.observe(el));
  } else rv.forEach(el => el.classList.add('in'));

  /* ---------- Menu mobile ---------- */
  const mb = $('#menuBtn');
  if (mb) mb.addEventListener('click', () => {
    const on = d.body.classList.toggle('menu-open');
    mb.setAttribute('aria-expanded', String(on)); mb.textContent = on ? 'Fermer' : 'Menu';
  });

  /* ---------- Transition de page (rideau rouge) ---------- */
  let busy = false;
  function go(href, label) {
    if (busy) return; busy = true;
    if (RM || !curtain) { location.href = href; return; }
    $('#cl').textContent = label || '';
    curtain.classList.add('active');
    curtain.style.transition = 'none'; curtain.style.transform = 'translateY(100%)';
    void curtain.offsetHeight;
    curtain.style.transition = EASE; curtain.style.transform = 'translateY(0)';
    try { sessionStorage.setItem('kdnav', '1'); } catch (e) {}
    setTimeout(() => { location.href = href; }, 680);
  }
  d.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target === '_blank' || a.hasAttribute('download')) return;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin || u.protocol === 'mailto:') return;
    if (u.pathname === location.pathname && u.search === location.search) return;
    if (/\.[a-z0-9]+$/i.test(u.pathname) && !/\.html$/i.test(u.pathname)) return;
    e.preventDefault(); go(u.href, a.dataset.label || '');
  });
  if (root.classList.contains('entering') && curtain) {
    curtain.style.transition = 'none'; curtain.style.transform = 'translateY(0)';
    root.classList.remove('entering'); void curtain.offsetHeight;
    requestAnimationFrame(() => {
      curtain.style.transition = EASE; curtain.style.transform = 'translateY(-100%)';
      setTimeout(() => { curtain.style.transition = 'none'; curtain.style.transform = 'translateY(100%)'; curtain.classList.remove('active'); }, 720);
    });
  }
  addEventListener('pageshow', e => { if (e.persisted && curtain) { busy = false; curtain.classList.remove('active'); curtain.style.transform = 'translateY(100%)'; } });

  /* ---------- Filtres de la page Work ---------- */
  $$('[data-filter]').forEach(b => b.addEventListener('click', () => {
    const f = b.dataset.filter;
    $$('[data-filter]').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    $$('.work-grid .card').forEach(c => {
      const show = f === 'all' || c.dataset.type === f; c.hidden = !show;
      if (show) { c.classList.remove('in'); void c.offsetWidth; c.classList.add('in'); }
    });
  }));

  /* ---------- Formulaire de contact + copie de l'e-mail ---------- */
  const form = $('#form');
  if (form) form.addEventListener('submit', e => {
    e.preventDefault();
    const f = new FormData(form), note = $('#note');
    if (!f.get('name').trim() || !/\S+@\S+\.\S+/.test(f.get('email')) || !f.get('message').trim()) { note.textContent = 'Renseigne ton nom, une adresse e-mail valide et ton message.'; return; }
    const subject = encodeURIComponent(`Portfolio — ${f.get('type')} — ${f.get('name')}`);
    const body = encodeURIComponent(`${f.get('message')}\n\n— ${f.get('name')} (${f.get('email')})`);
    note.textContent = 'Ton application e-mail va s\u2019ouvrir avec le message prêt à envoyer.';
    location.href = `mailto:${form.dataset.to}?subject=${subject}&body=${body}`;
  });
  const copy = $('#copyMail');
  if (copy) copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(copy.dataset.mail); copy.textContent = 'Adresse copiée'; } catch (e) { copy.textContent = copy.dataset.mail; }
    setTimeout(() => { copy.textContent = 'Copier l\u2019adresse'; }, 2200);
  });

  /* ---------- Curseur, aimants, lettres ---------- */
  if (!FINE) return;
  const dot = $('#cDot'), ring = $('#cRing'), lab = $('#cLabel');
  let mx = -200, my = -200, rx = -200, ry = -200, on = false;
  const mags = $$('.mag');
  addEventListener('pointermove', e => {
    if (e.pointerType !== 'mouse') return;
    mx = e.clientX; my = e.clientY;
    if (!on) { on = true; rx = mx; ry = my; d.body.classList.add('has-cursor'); dot.classList.add('on'); ring.classList.add('on'); }
    mags.forEach(el => {
      const r = el.getBoundingClientRect(), dx = mx - (r.left + r.width / 2), dy = my - (r.top + r.height / 2);
      el.style.transform = Math.hypot(dx, dy) < Math.max(r.width, r.height) * .75 ? `translate(${dx * .22}px,${dy * .3}px)` : '';
    });
  });
  d.addEventListener('mouseleave', () => { dot.classList.remove('on'); ring.classList.remove('on'); on = false; });
  d.addEventListener('mouseover', e => {
    const b = d.body.classList; b.remove('cur-link', 'cur-view', 'cur-text');
    const t = e.target.closest('[data-cursor],a,button,input,textarea,label,summary');
    if (!t) return;
    if (t.matches('input:not([type=radio]),textarea')) b.add('cur-text');
    else if (t.dataset.cursor) { lab.textContent = t.dataset.cursor; b.add('cur-view'); }
    else b.add('cur-link');
  });
  (function tick() {
    if (on) {
      dot.style.transform = `translate3d(${mx}px,${my}px,0)`;
      const k = RM ? 1 : .2; rx += (mx - rx) * k; ry += (my - ry) * k;
      ring.style.transform = `translate3d(${rx}px,${ry}px,0)`;
      if (!RM) for (const o of letters) {
        const r = o.el.getBoundingClientRect();
        if (r.bottom < 0 || r.top > innerHeight) continue;
        const dist = Math.hypot(mx - (r.left + r.width / 2), my - (r.top + r.height / 2));
        const target = BASE + (MAX - BASE) * Math.exp(-Math.pow(dist / (r.height * 1.25), 2));
        const nw = o.w + (target - o.w) * .14;
        if (Math.abs(nw - o.w) > .04) { o.w = nw; o.el.style.fontStretch = nw.toFixed(2) + '%'; }
      }
    }
    requestAnimationFrame(tick);
  })();
})();
